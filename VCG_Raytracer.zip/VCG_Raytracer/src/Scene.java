import java.util.ArrayList;
import sceneobjects.*;
import utils.RgbColor;
import utils.Vec3;

public class Scene {
    //private ArrayList<Shape> shapeList = new ArrayList<>();
    //private ArrayList<Light> lightList = new ArrayList<>();

    public Scene(){

    }

    public void createSphere(){

    }

    public void createPlane(){

    }

    public void createPointLight(){

    }

    public void createPerspCamera(){

    }
}
