import utils.*;



public class Ray {

    public Ray(){

    }

    private Vec3 startPoint(){

        //Dummy return value
        return new Vec3();
    }

    private Vec3 endPoint(){

        //Dummy return value
        return new Vec3();
    }

    private Vec3 direction(){

        //Dummy return value
        return new Vec3();
    }

    private float distance(){

        //Dummy return value
        return 0;
    }
}
