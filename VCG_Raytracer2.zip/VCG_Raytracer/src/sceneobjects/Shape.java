package sceneobjects;

import raytracer.Ray;

/**
 * Created by PraktikumCG on 03.05.2016.
 */
public abstract class Shape extends SceneObject {


    public boolean intersect (Ray ray) {



        return false;
    }

}
