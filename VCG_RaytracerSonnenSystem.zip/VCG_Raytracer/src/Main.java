// ************************************************************ //
//                      Hochschule Duesseldorf                  //
//                                                              //
//                     Vertiefung Computergrafik                //
// ************************************************************ //


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    1. Documentation:    Did you comment your code shortly but clearly?
    2. Structure:        Did you clean up your code and put everything into the right bucket?
    3. Performance:      Are all loops and everything inside really necessary?
    4. Theory:           Are you going the right way?

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

 <<< YOUR TEAM NAME >>>

     Master of Documentation:
     Master of Structure:
     Master of Performance:
     Master of Theory:

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

import ui.Window;
import raytracer.*;
import utils.Log;
import utils.Vec3;
import sceneobjects.*;

public class Main {

    static int IMAGE_WIDTH = 800;
    static int IMAGE_HEIGHT = 600;
    //int counter= 0;

    // Initial method. This is where the show begins.
    public static void main(String[] args){
        long tStart = System.currentTimeMillis();
        int counter= 0;
        Window renderWindow = new Window(IMAGE_WIDTH, IMAGE_HEIGHT, counter);
        while(counter<360) {
            //Window renderWindow = new Window(IMAGE_WIDTH, IMAGE_HEIGHT, counter);
            draw(renderWindow, counter);
            //enderWindow.dispose();
            counter++;

        }
        //renderWindow.setTimeToLabel(String.valueOf(stopTime(tStart)));
    }

    private static void draw(Window renderWindow, int counter){
        raytraceScene(renderWindow, counter);

    }

    private static void raytraceScene(Window renderWindow, int counter){
        Raytracer raytracer = new Raytracer(renderWindow);

        raytracer.renderScene(counter);
    }

    private static double stopTime(long tStart){
        long tEnd = System.currentTimeMillis();
        long tDelta = tEnd - tStart;
        return tDelta / 1000.0;
    }
}
